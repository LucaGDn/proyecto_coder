# proyecto_coder

Para ingresar a la aplicacion /app

inicio del proyecto y aplicacion: Matías Barreto
Seteo de vistas y URLs: Matías Barreto
Templates descargadas de https://www.free-css.com/free-css-templates/page250/runner-onepage
Templates personalizadas por: Matías Barreto