from django.apps import AppConfig


class AppProyectofinalConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'app_proyectoFinal'
