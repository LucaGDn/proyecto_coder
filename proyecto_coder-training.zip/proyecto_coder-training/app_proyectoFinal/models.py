from django.db.models import Model
from django.db.models.fields import CharField, IntegerField, EmailField, DateField

# Create your models here.

class Atleta(Model):

    nombre = CharField(max_length=40)
    apellido = CharField(max_length=40)
    edad= IntegerField()
    altura= IntegerField()
    peso= IntegerField()
    email = EmailField()
    def __str__(self):
        return f'Nombre y apellido: {self.nombre} {self.apellido} Edad: {self.edad} Altura: {self.altura} Peso: {self.peso} Email: {self.email}'

class Entrenador(Model):

    nombre = CharField(max_length=40)
    apellido = CharField(max_length=40)
    email = EmailField()
    profesion = CharField(max_length=50)
    def __str__(self):
        return f'Nombre y apellido: {self.nombre} {self.apellido} Profesion: {self.profesion} Email: {self.email}'

class Rutina(Model):

    nombre = CharField(max_length=40)
    fecha_inicio = DateField()
    intensidad = CharField(max_length=10)
    ejercicio_1 = CharField(max_length=40)
    ejercicio_2 = CharField(max_length=40)
    ejercicio_3 = CharField(max_length=40)
    ejercicio_4 = CharField(max_length=40)
    ejercicio_5 = CharField(max_length=40)
    ejercicio_6 = CharField(max_length=40)
    ejercicio_7 = CharField(max_length=40)
    duracionPorEjercicio = IntegerField()
    descansoEntreEjercicio = IntegerField()
    rondas = IntegerField()
    
    def __str__(self):
        return f'Rutina: {self.nombre} Intensidad: {self.intensidad} Ejercicio 1: {self.ejercicio_1}'